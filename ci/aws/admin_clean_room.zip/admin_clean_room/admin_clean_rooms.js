const WebSocket = require('ws')

const ws = new WebSocket("ws://127.0.0.1:7188/admin", "janus-admin-protocol")

ws.on('open', function open() { 
  //console.log("CONNECTED")
  list_request = { "janus": "message_plugin", "admin_secret": "gh95489233453admin", "transaction": "1", "request": { "request": "list" } }
  list_request.plugin = "janus.plugin.videoroom"
  doSend(list_request)
})

ws.on('error', function close(e) {
  console.log(e)
})

ws.on('message', function incoming(data) {
  json = JSON.parse(data)
  
  
  if(json.response["videoroom"] == "destroyed" ){
    list = ""
    console.log("Room: "+json.response["room"]+" destroyed")
  } else {
    list = json.response.list
  }
  if (!list && list.length === 0) {
    //console.log("No rooms")
  } else {
    var datenow = new Date()
    var timenow = datenow.getTime()
    for(i=0; i<list.length; i++){
      room = list[i].room
      members = list[i].num_participants
      var expirationtime=parseInt(list[i].description, 10); 
      if(members == 0) {
        if(timenow > expirationtime || !isNumeric(list[i].description)  ) {      
          console.log("Room: "+room+ " with expirationtime:" +expirationtime+"  timenow:"+timenow+" has "+members+" members , destroy")
          destroy_request = { "janus": "message_plugin", "admin_secret": "gh95489233453admin", "transaction": "1", "request": { "request": "destroy", "room": room } }
          destroy_request.plugin = "janus.plugin.videoroom"
          doSend(destroy_request) 
        }
        else {
          console.log("Room: "+room+" has "+members+" members, but time not expired:" +expirationtime+"  timenow:"+timenow)
        }
      } else {
        console.log("Room: "+room+" has "+members+" members, not empty")
      }
    }
  }
  ws.close()
})

function isNumeric(num){
  return !isNaN(num)
}

function doSend(message) {
  var message = JSON.stringify(message)
  //console.log('SENT: ' + message)
  ws.send(message)
}

